        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/sbadmin-2') ?>/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?= base_url('assets/sbadmin-2') ?>/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?= base_url('assets/sbadmin-2') ?>/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url('assets/sbadmin-2') ?>/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="<?= base_url('assets/sbadmin-2') ?>/vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Bootstrap Datepicker JavaScript -->
    <script src="<?= base_url('assets/datepicker') ?>/js/bootstrap-datepicker.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url('assets/sbadmin-2') ?>/dist/js/sb-admin-2.js"></script>

</body>

</html>
