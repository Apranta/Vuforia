<?php

	$this->load->view('template/header', array('title' => $title));
	$this->load->view('template/sidebar');
	$this->load->view($content);
	$this->load->view('template/footer');
?>
